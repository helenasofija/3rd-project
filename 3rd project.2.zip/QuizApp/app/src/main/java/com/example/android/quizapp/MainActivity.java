package com.example.android.quizapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    public static final String COOKIES = "cookies";
    public static final String COOKIE = "cookie";
    public static Set<Food> selected = new HashSet<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        * This method is called when the done button is clicked.
        */

        Button b = findViewById(R.id.done_button);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();
                TextView cookieQuestionTextView = findViewById(R.id.cookie_question);
                CharSequence cookiesAnswer = cookieQuestionTextView.getText();
                String answer = cookiesAnswer.toString();
                int score = 0;
                if (answer.equalsIgnoreCase(COOKIES)||answer.equalsIgnoreCase(COOKIE)){
                    score += 1;
                }
                CheckBox eggplantCheckBox = findViewById(R.id.eggplant);
                if (eggplantCheckBox.isChecked()){
                 score += 1;
                }
                CheckBox aubergineCheckBox = findViewById(R.id.aubergine);
                if (aubergineCheckBox.isChecked()){
                    score += 1;
                }

                for (Food food : selected) {
                    score += food.getScore();
                }

                CharSequence text = " Your score: " + score + "/9";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });
    }

    /*
    * This calculates the points player receives.
    */
    public void onAnswer(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (!checked) {
            return;
        }

        int radioButtonId = view.getId();

        if (radioButtonId == R.id.honey_dew) {
            selected.add(Food.HONEY_DEW);
            selected.remove(Food.CANTALOUPE);
        } else if (radioButtonId == R.id.cantaloupe) {
            selected.add(Food.CANTALOUPE);
            selected.remove(Food.HONEY_DEW);
        } else if (radioButtonId == R.id.lemon) {
            selected.add(Food.LEMON);
            selected.remove(Food.LIME);
        } else if (radioButtonId == R.id.lime) {
            selected.add(Food.LIME);
            selected.remove(Food.LEMON);
        } else if (radioButtonId == R.id.bbq_sauce) {
            selected.add(Food.BBQ_SAUCE);
            selected.remove(Food.KETCHUP);
        } else if (radioButtonId == R.id.ketchup) {
            selected.add(Food.KETCHUP);
            selected.remove(Food.BBQ_SAUCE);
        } else if (radioButtonId == R.id.sweet_potato) {
            selected.add(Food.SWEET_POTATO);
            selected.remove(Food.POTATO);
        } else if (radioButtonId == R.id.potato) {
            selected.add(Food.POTATO);
            selected.remove(Food.SWEET_POTATO);
        } else if (radioButtonId == R.id.banana) {
            selected.add(Food.BANANA);
            selected.remove(Food.PLANTAIN);
        } else if (radioButtonId == R.id.plantain) {
            selected.add(Food.PLANTAIN);
            selected.remove(Food.BANANA);
        } else if (radioButtonId == R.id.cocoa_powder) {
            selected.add(Food.COCOA_POWDER);
            selected.remove(Food.COFFEE);
        } else if (radioButtonId == R.id.coffee) {
            selected.add(Food.COFFEE);
            selected.remove(Food.COCOA_POWDER);
        }
    }
}

