package com.example.android.quizapp;

/**
 * Created by Sofie on 4/7/2018.
 */

public enum Food {
    HONEY_DEW(1),
    CANTALOUPE(0),
    LEMON(1),
    LIME(0),
    BBQ_SAUCE(0),
    KETCHUP(1),
    SWEET_POTATO(0),
    POTATO(1),
    BANANA(0),
    PLANTAIN(1),
    COCOA_POWDER(0),
    COFFEE(1);

    private final int score;

    Food(int score) {
        this.score = score;
    }

    public int getScore() {
        return score;
    }
}
